
import { GoogleGenAI } from "@google/genai";
import { FashionState, ProductState, StudioTab, MODEL_DATABASE, POSE_DATABASE, GARMENT_HIERARCHY, BOTTOM_DATABASE, HemlinePosition, ShortKurtiStyling, AdditionalLayer } from "../types";

// Helper to convert File to Base64 with robust MIME type detection
const fileToGenerativePart = async (file: File): Promise<{ inlineData: { data: string; mimeType: string } }> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const base64String = reader.result as string;
      if (!base64String || typeof base64String !== 'string') {
         reject(new Error("Failed to read file"));
         return;
      }
      const base64Data = base64String.split(',')[1];
      
      // FIX: Robust MIME type detection
      let mimeType = file.type;
      if (!mimeType || mimeType === '' || mimeType === 'application/octet-stream') {
        const ext = file.name.split('.').pop()?.toLowerCase();
        switch (ext) {
          case 'png': mimeType = 'image/png'; break;
          case 'jpg':
          case 'jpeg': mimeType = 'image/jpeg'; break;
          case 'webp': mimeType = 'image/webp'; break;
          case 'heic': mimeType = 'image/heic'; break;
          case 'heif': mimeType = 'image/heif'; break;
          default: mimeType = 'image/jpeg'; // Default safe fallback
        }
      }

      resolve({
        inlineData: {
          data: base64Data,
          mimeType: mimeType,
        },
      });
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
};

export const analyzeGarmentImage = async (file: File): Promise<{
  mainCategory: string;
  subCategory: string;
  fabricType: string;
  pattern: string;
  constructionDetails: string;
  hemlinePosition: HemlinePosition;
  shortKurtiStyling: ShortKurtiStyling;
}> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const modelId = "gemini-3-flash-preview"; 
  const imagePart = await fileToGenerativePart(file);

  const westernList = GARMENT_HIERARCHY['Western Wear'].join(', ');
  const ethnicList = GARMENT_HIERARCHY['Ethnic Wear'].join(', ');

  const prompt = `
    Role: Senior Fashion Forensics Expert. 
    Analyze the garment in the image for precise classification and construction.
    
    1. CATEGORIZATION (MANDATORY):
       - mainCategory: Must be exactly "Western Wear" or "Ethnic Wear".
       - subCategory: Choose the most accurate from these lists:
         Western: [${westernList}]
         Ethnic: [${ethnicList}]

    Output format MUST be JSON: {
      "mainCategory": "Western Wear" | "Ethnic Wear", 
      "subCategory": "string", 
      "fabricType": "string",
      "pattern": "string",
      "constructionDetails": "string summary",
      "hemlinePosition": "top of hip bone" | "mid-hip" | "upper thigh",
      "shortKurtiStyling": "Straight Fit" | "A-Line" | "Peplum" | "Front Tuck" | "Asymmetric" | "Side Tie" | "High-Low" | "Tiered"
    }.
  `;

  try {
    const response = await ai.models.generateContent({
      model: modelId,
      contents: { parts: [imagePart, { text: prompt }] },
      config: { responseMimeType: "application/json" }
    });
    
    if (!response.text) throw new Error("Empty response from analysis");
    const parsed = JSON.parse(response.text);
    return { 
      mainCategory: parsed.mainCategory || "Western Wear", 
      subCategory: parsed.subCategory || "T-Shirt", 
      fabricType: parsed.fabricType || "Standard Fabric",
      pattern: parsed.pattern || "Solid",
      constructionDetails: parsed.constructionDetails || "Standard Cut",
      hemlinePosition: parsed.hemlinePosition || "top of hip bone",
      shortKurtiStyling: parsed.shortKurtiStyling || "Straight Fit"
    };
  } catch (error) {
    console.error("Analysis Error:", error);
    return { 
      mainCategory: "Western Wear", 
      subCategory: "T-Shirt", 
      fabricType: "Cotton", 
      pattern: "Solid", 
      constructionDetails: "Regular fit",
      hemlinePosition: "top of hip bone",
      shortKurtiStyling: "Straight Fit"
    };
  }
};

export const generateStudioImage = async (
  mode: StudioTab,
  data: FashionState | ProductState,
  variationSeed?: string,
  viewOverride?: string
): Promise<string> => {
  
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const modelId = 'gemini-2.5-flash-image'; 

  const parts: any[] = [];
  let prompt = "";
  let targetAspectRatio = "3:4"; 

  const resolutionPrompt = '8k resolution, ultra-photorealistic, high-end fashion editorial photography, crisp fabric textures, professional studio lighting, sharp focus';

  if (mode === StudioTab.FASHION) {
    const fd = data as FashionState;
    if (!fd.image) throw new Error("Please upload a cloth image.");
    
    const topPart = await fileToGenerativePart(fd.image);
    parts.push(topPart);
    
    let compositionPrompt = `Image 1 is the main garment (${fd.subCategory}).`;
    
    let layerCounter = 2;
    for (const layer of fd.additionalLayers) {
      if (layer.file) {
        const layerPart = await fileToGenerativePart(layer.file);
        parts.push(layerPart);
        compositionPrompt += ` Image ${layerCounter} is the ${layer.label}.`;
        layerCounter++;
      }
    }

    let bottomInstruction = "STYLING: Use matching professional bottom garment.";
    if (fd.bottomType === 'library' && fd.selectedBottomId) {
      const selectedBottom = BOTTOM_DATABASE.find(b => b.id === fd.selectedBottomId);
      if (selectedBottom) {
          bottomInstruction = `STYLING: The model is wearing ${selectedBottom.physicalDescription}.`;
      }
    } else if (fd.bottomType === 'upload' && fd.bottomImage) {
        const bottomPart = await fileToGenerativePart(fd.bottomImage);
        parts.push(bottomPart);
        bottomInstruction = `STYLING: The model is wearing bottom garment shown in Image ${layerCounter}.`;
        layerCounter++;
    }

    const selectedModel = MODEL_DATABASE.find(m => m.id === fd.modelType) || MODEL_DATABASE[0];
    const selectedPose = POSE_DATABASE.find(p => p.id === fd.pose);
    const poseLabel = selectedPose ? selectedPose.label : "Standing naturally";
    const effectiveView = viewOverride || fd.view;
    
    prompt = `
      TASK: Premium commercial fashion photography.
      REFERENCE: ${compositionPrompt} Combine all provided items.
      MODEL: ${selectedModel.label}, ${selectedModel.physicalDescription}.
      VIEW: ${effectiveView}, POSE: ${poseLabel}.
      BACKDROP: ${fd.bgCategory === 'Upload' ? 'Custom environment' : fd.bgPrompt}.
      QUALITY: ${resolutionPrompt}.
    `;

  } else {
    const pd = data as ProductState;
    if (!pd.image) throw new Error("Please upload a product image.");
    const imagePart = await fileToGenerativePart(pd.image);
    parts.push(imagePart);
    prompt = `COMMERCIAL PRODUCT SHOT: ${pd.subCategory}. Lighting: ${pd.lighting}. ${resolutionPrompt}.`;
  }

  if (variationSeed) prompt += `\n\nVARIATION_SEED: ${variationSeed}.`;
  parts.push({ text: prompt });

  const response = await ai.models.generateContent({
    model: modelId,
    contents: { parts },
    config: { imageConfig: { aspectRatio: targetAspectRatio } }
  });

  const candidates = response.candidates || [];
  if (candidates.length > 0) {
      for (const part of candidates[0].content?.parts || []) {
        if (part.inlineData) return `data:image/png;base64,${part.inlineData.data}`;
      }
  }
  throw new Error("Generation failed: No image part returned.");
};
