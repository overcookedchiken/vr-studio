
# Virtual Studio AI - Fashion & Product Studio

India's first AI-based fashion studio. Generate hyper-realistic photography in seconds using Gemini 2.5 and Supabase.

## 🚀 Deployment to GitHub

1. **Create a new Repository** on GitHub (e.g., `virtual-studio`).
2. **Push your code**:
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/virtual-studio.git
   git push -u origin main
   ```

## 🔑 Configuration

To ensure the AI works after deployment, you must set up your API Key:

1. Go to your GitHub Repository **Settings**.
2. Navigate to **Secrets and variables** > **Actions**.
3. Click **New repository secret**.
4. Name: `GEMINI_API_KEY`.
5. Value: *Paste your Google Gemini API Key*.

## 🛠 Development

This app is built with:
- **React 19** & **Vite**
- **Tailwind CSS** (Styling)
- **Supabase** (Auth & Database)
- **Google Gemini API** (AI Vision & Image Generation)

To run locally:
```bash
npm install
npm run dev
```

---
Built by Senior Frontend Engineering Team.
