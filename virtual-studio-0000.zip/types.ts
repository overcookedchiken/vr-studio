
export enum AppMode {
  LANDING = 'LANDING',
  APP = 'APP'
}

export enum StudioTab {
  FASHION = 'FASHION',
  PRODUCT = 'PRODUCT'
}

export interface Project {
  id: string;
  name: string;
  image: string;
  type: 'FASHION' | 'PRODUCT';
  timestamp: number;
}

export interface Generation {
  id: string;
  projectId: string;
  image: string;
  type: StudioTab;
  settings: FashionState | ProductState;
  timestamp: number;
}

export type MainGarmentCategory = 'Western Wear' | 'Ethnic Wear';

export const GARMENT_HIERARCHY: Record<MainGarmentCategory, string[]> = {
  'Western Wear': [
    "T-Shirt", "Formal Shirt", "Casual Shirt", "Blouse", "Crop Top", "Hoodie", "Sweater", "Jacket", "Blazer", "Tank Top", "Corset", "Lingerie",
    "Jeans", "Trousers", "Skirt (Mini)", "Skirt (Midi/Maxi)", "Shorts", "Leggings", "Joggers", "Cargo Pants",
    "Dress (Casual)", "Dress (Evening Gown)", "Jumpsuit", "Romper", "Business Suit", "Swimwear", "Co-ord Set",
    "Overcoat", "Trench Coat", "Puffer Jacket", "Leather Jacket"
  ],
  'Ethnic Wear': [
    "Saree", "Lehenga Choli", "Kurta Set", "Anarkali Suit", "Salwar Kameez", "Sharara Set", "Gharara", "Ethnic Gown", "Saree Blouse", "Dupatta", "Short Kurti",
    "Kurta Pajama", "Sherwani", "Nehru Jacket", "Dhoti Kurta Set", "Pathani Suit", "Bandhgala", "Indo-Western Set"
  ]
};

export const TOP_CATEGORIES = ["T-Shirt", "Formal Shirt", "Casual Shirt", "Blouse", "Crop Top", "Hoodie", "Sweater", "Tank Top", "Corset", "Jacket", "Blazer", "Short Kurti"];

export type PropCategory = 'None' | 'Bags' | 'Tech' | 'Lifestyle' | 'Travel' | 'Studio' | 'Accessories';

export interface PropDef {
  id: string;
  label: string;
  category: PropCategory;
  prompt: string;
}

export const PROP_DATABASE: Record<PropCategory, PropDef[]> = {
  'None': [{ id: 'none', label: 'No Prop', category: 'None', prompt: '' }],
  'Bags': [
    { id: 'prop_handbag', label: 'Leather Handbag', category: 'Bags', prompt: 'holding a luxury designer leather handbag' },
    { id: 'prop_tote', label: 'Canvas Tote', category: 'Bags', prompt: 'carrying a minimalist canvas tote bag' }
  ],
  'Tech': [
    { id: 'prop_phone', label: 'Smartphone', category: 'Tech', prompt: 'holding a modern sleek smartphone' },
    { id: 'prop_headphones', label: 'Headphones', category: 'Tech', prompt: 'wearing premium wireless over-ear headphones' }
  ],
  'Lifestyle': [
    { id: 'prop_coffee', label: 'Coffee Cup', category: 'Lifestyle', prompt: 'holding a takeaway coffee cup' },
    { id: 'prop_flowers', label: 'Flower Bouquet', category: 'Lifestyle', prompt: 'holding a beautiful bouquet of fresh seasonal flowers' }
  ],
  'Travel': [
    { id: 'prop_umbrella', label: 'Clear Umbrella', category: 'Travel', prompt: 'holding a stylish clear bubble umbrella' },
    { id: 'prop_suitcase', label: 'Travel Suitcase', category: 'Travel', prompt: 'standing next to a premium hard-shell travel suitcase' }
  ],
  'Studio': [
    { id: 'prop_stool', label: 'Minimalist Stool', category: 'Studio', prompt: 'sitting on or leaning against a minimalist designer studio stool' }
  ],
  'Accessories': [
    { id: 'prop_glasses', label: 'Sunglasses', category: 'Accessories', prompt: 'wearing chic designer sunglasses' }
  ]
};

export const PROPS = ['None', 'Handbag', 'Coffee Cup', 'Smartphone', 'Sunglasses'];

export interface BottomDef {
  id: string;
  label: string;
  description: string;
  physicalDescription: string;
  thumbnail: string;
}

export const BOTTOM_DATABASE: BottomDef[] = [
  {
    id: 'b1',
    label: 'Indigo Denim',
    description: 'Classic straight-cut dark denim',
    physicalDescription: 'Straight-leg raw indigo denim jeans with contrast orange stitching and slight structural stiffness.',
    thumbnail: 'https://images.unsplash.com/photo-1542272604-787c3835535d?q=80&w=200&auto=format&fit=crop'
  },
  {
    id: 'b2',
    label: 'Beige Chinos',
    description: 'Clean tailored cotton trousers',
    physicalDescription: 'Slim-fit beige cotton chinos with a clean pressed crease and matte texture.',
    thumbnail: 'https://images.unsplash.com/photo-1624371414361-e6e9ea58c33c?q=80&w=200&auto=format&fit=crop'
  },
  {
    id: 'b3',
    label: 'Black Skirt',
    description: 'Minimalist silk mini skirt',
    physicalDescription: 'A high-waisted minimalist black silk mini skirt with a slight sheen.',
    thumbnail: 'https://images.unsplash.com/photo-1582142306909-195724d33ffc?q=80&w=200&auto=format&fit=crop'
  }
];

export interface ModelDef {
  id: string;
  label: string;
  category: 'Men' | 'Women' | 'Boys' | 'Girls';
  description: string;
  physicalDescription: string;
  colorHex: string;
  avatar: string;
}

export const MODEL_DATABASE: ModelDef[] = [
  { id: 'm1', label: 'Leo', category: 'Men', description: 'Classic handsome', physicalDescription: 'Caucasian male, fair skin, warm undertones. Short dark brown hair, square jaw, blue eyes.', colorHex: '#f5d0b0', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=200' },
  { id: 'm2', label: 'Kai', category: 'Men', description: 'Edgy modern', physicalDescription: 'East Asian male, light beige skin. Textured black undercut hair, sharp cheekbones.', colorHex: '#f8e4d2', avatar: 'https://images.unsplash.com/photo-1552374196-c4e7ffc6e126?q=80&w=200' },
  { id: 'm3', label: 'Marcus', category: 'Men', description: 'Rugged mature', physicalDescription: 'African American male, deep dark skin. Buzz cut fade, full groomed beard.', colorHex: '#5c3a2a', avatar: 'https://images.unsplash.com/photo-1531384441138-2736e62e0919?q=80&w=200' },
  { id: 'm4', label: 'Nico', category: 'Men', description: 'Mediterranean', physicalDescription: 'Latino male, olive tan skin. Curly dark brown hair, slight facial stubble.', colorHex: '#c68642', avatar: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?q=80&w=200' },
  { id: 'm5', label: 'Aryan', category: 'Men', description: 'Artistic', physicalDescription: 'South Asian male, golden brown skin. Wavy black hair, expressive dark eyes.', colorHex: '#8d5524', avatar: 'https://images.unsplash.com/photo-1503443207922-dff7d543fd0e?q=80&w=200' },
  { id: 'f1', label: 'Emma', category: 'Women', description: 'Editorial', physicalDescription: 'Northern European female, pale skin. Long straight platinum blonde hair, high cheekbones.', colorHex: '#ffe0bd', avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?q=80&w=200' },
  { id: 'f2', label: 'Zara', category: 'Women', description: 'Chic modern', physicalDescription: 'Middle Eastern female, olive skin. Sleek dark bob cut, arched brows.', colorHex: '#c58c85', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=200' },
  { id: 'f3', label: 'Priya', category: 'Women', description: 'Warm commercial', physicalDescription: 'Indian female, golden brown skin. Long voluminous wavy black hair.', colorHex: '#a16e4b', avatar: 'https://images.unsplash.com/photo-1531123897727-8f129e1688ce?q=80&w=200' },
  { id: 'f4', label: 'Nia', category: 'Women', description: 'High fashion', physicalDescription: 'African female, deep ebony skin. Short natural afro-textured hair, symmetrical features.', colorHex: '#3b2219', avatar: 'https://images.unsplash.com/photo-1531123414780-f74242c2b052?q=80&w=200' },
  { id: 'f5', label: 'Hana', category: 'Women', description: 'Sporty', physicalDescription: 'Asian female, light warm skin. High ponytail, fresh face look.', colorHex: '#f1c27d', avatar: 'https://images.unsplash.com/photo-1508214751196-bcfd4ca60f91?q=80&w=200' },
];

export interface PoseDef {
  id: string;
  label: string;
  category: string;
  iconType: 'walk' | 'sit' | 'jump' | 'face' | 'default';
}

export const POSE_DATABASE: PoseDef[] = [
  // --- STANDING ---
  { id: 'p1', label: 'Natural Standing', category: 'Standing', iconType: 'default' },
  { id: 'p2', label: 'Model Walk', category: 'Standing', iconType: 'walk' },
  { id: 'p6', label: 'Side Profile', category: 'Standing', iconType: 'default' },
  { id: 'p7', label: 'Hands on Hips', category: 'Standing', iconType: 'default' },
  { id: 'p13', label: 'Hands in Pockets', category: 'Standing', iconType: 'default' },
  { id: 'p14', label: 'Leaning on Wall', category: 'Standing', iconType: 'default' },
  { id: 'p28', label: 'Legs Crossed', category: 'Standing', iconType: 'default' },
  { id: 'p31', label: 'Back View', category: 'Standing', iconType: 'default' },

  // --- SITTING ---
  { id: 'p3', label: 'Seated Editorial', category: 'Sitting', iconType: 'sit' },
  { id: 'p11', label: 'Sitting on Floor', category: 'Sitting', iconType: 'sit' },
  { id: 'p19', label: 'Sitting on Stool', category: 'Sitting', iconType: 'sit' },
  { id: 'p18', label: 'Squatting Low', category: 'Sitting', iconType: 'sit' },

  // --- DYNAMIC ---
  { id: 'p17', label: 'Mid-Twirl', category: 'Dynamic', iconType: 'jump' },
  { id: 'p29', label: 'Dynamic Jump', category: 'Dynamic', iconType: 'jump' },
  { id: 'p22', label: 'Walking Away', category: 'Dynamic', iconType: 'walk' },
  { id: 'p16', label: 'Hands Through Hair', category: 'Dynamic', iconType: 'default' },

  // --- EDITORIAL ---
  { id: 'p12', label: 'Over-the-Shoulder', category: 'Editorial', iconType: 'default' },
  { id: 'p20', label: 'Arms Crossed High', category: 'Editorial', iconType: 'default' },
  { id: 'p27', label: 'One Hand on Head', category: 'Editorial', iconType: 'default' },
  { id: 'p30', label: 'Leaning Forward', category: 'Editorial', iconType: 'default' },
  { id: 'p5', label: 'Portrait Close-up', category: 'Editorial', iconType: 'face' },

  // --- ETHNIC ---
  { id: 'p23', label: 'Traditional Greeting', category: 'Ethnic', iconType: 'default' },
  { id: 'p24', label: 'Holding Pallu/Hem', category: 'Ethnic', iconType: 'default' },
  { id: 'p25', label: 'Adjusting Earring', category: 'Ethnic', iconType: 'face' },
  { id: 'p26', label: 'Looking Down Shyly', category: 'Ethnic', iconType: 'face' },

  // --- LIFESTYLE ---
  { id: 'p21', label: 'Looking at Watch', category: 'Lifestyle', iconType: 'default' },
  { id: 'p15', label: 'Adjusting Collar', category: 'Lifestyle', iconType: 'default' },
];

export type ViewAngle = 'Front' | 'Back' | 'Left Side' | 'Right Side' | 'Closeup' | 'Blouse: Front' | 'Blouse: Back' | 'Blouse: Sleeves';
export const VIEW_ANGLES: ViewAngle[] = ['Front', 'Back', 'Left Side', 'Right Side', 'Closeup'];

export type FaceExpression = 'Neutral' | 'Smiling' | 'Serious' | 'Editorial' | 'Soft';
export const FACE_EXPRESSIONS: FaceExpression[] = ['Neutral', 'Smiling', 'Serious', 'Editorial', 'Soft'];

export type BackgroundCategory = 'Solid' | 'Lifestyle' | 'Outdoor' | 'Creative' | 'Upload';

export interface BackgroundPreset {
  id: string;
  label: string;
  prompt: string;
  src: string;
  isColor?: boolean;
}

export const BACKGROUND_PRESETS: Record<BackgroundCategory, BackgroundPreset[]> = {
  Solid: [
    { id: 'bg_white', label: 'Pure White', prompt: 'Clean pure white studio background', src: '#ffffff', isColor: true },
    { id: 'bg_grey', label: 'Soft Grey', prompt: 'Soft professional grey studio background', src: '#f0f0f0', isColor: true },
    { id: 'bg_black', label: 'Deep Black', prompt: 'Dramatic solid black studio background', src: '#000000', isColor: true },
  ],
  Lifestyle: [
    { id: 'bg_living_room', label: 'Sunlit Living Room', prompt: 'Modern minimalist living room interior, warm natural sunlight streaming from a large window, clean white walls, decorative wall hangings, indoor plants, professional home catalog photography', src: 'https://images.unsplash.com/photo-1583847268964-b28dc2f51ac9?q=80&w=400' },
    { id: 'bg_boutique', label: 'Luxury Boutique', prompt: 'High-end fashion boutique interior, warm ambient lighting, minimalist decor', src: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?q=80&w=400' },
    { id: 'bg_balcony', label: 'Urban Balcony', prompt: 'Stylish apartment balcony, cityscape view in background, soft natural daylight', src: 'https://images.unsplash.com/photo-1598928506311-c55ded91a20c?q=80&w=400' },
  ],
  Outdoor: [
    { id: 'bg_street', label: 'Urban Street', prompt: 'New York City street background, soft morning light, bokeh', src: 'https://images.unsplash.com/photo-1477959858617-67f85cf4f1df?q=80&w=200' },
    { id: 'bg_park', label: 'Sunlit Park', prompt: 'Lush green park background, dappled sunlight', src: 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?q=80&w=200' },
  ],
  Creative: [
    { id: 'bg_neon', label: 'Cyberpunk', prompt: 'Neon-lit cyberpunk city alley at night', src: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?q=80&w=200' },
  ],
  Upload: []
};

export const LIGHTING_OPTIONS = ['Studio Softbox', 'Natural Sunlight', 'Golden Hour', 'Dramatic Cinematics', 'High-Key White', 'Cyberpunk Neon'];

export type MainProductCategory = 'Cosmetics & Beauty' | 'Electronics' | 'Home & Living' | 'Fashion Accessories';

export const PRODUCT_HIERARCHY: Record<MainProductCategory, string[]> = {
  'Cosmetics & Beauty': ['Lipstick', 'Perfume', 'Face Cream', 'Mascara'],
  'Electronics': ['Smartphone', 'Headphones', 'Smartwatch', 'Camera Lens'],
  'Home & Living': ['Candle', 'Vase', 'Cushion', 'Table Lamp'],
  'Fashion Accessories': ['Watch', 'Sunglasses', 'Handbag', 'Wallet']
};

export type HemlinePosition = 'top of hip bone' | 'mid-hip' | 'upper thigh';
export type ShortKurtiStyling = 'Straight Fit' | 'A-Line' | 'Peplum' | 'Front Tuck' | 'Asymmetric' | 'Side Tie' | 'High-Low' | 'Tiered';

export interface AdditionalLayer {
  id: string;
  label: string;
  file: File | null;
  preview: string | null;
}

export interface FashionState {
  mainCategory: MainGarmentCategory;
  subCategory: string;
  image: File | null;
  imagePreview: string | null;
  backImage: File | null;
  backImagePreview: string | null;
  
  // New multi-part support
  additionalLayers: AdditionalLayer[];

  bottomType: 'library' | 'upload' | 'none';
  bottomImage: File | null;
  bottomImagePreview: string | null;
  selectedBottomId: string | null;

  view: ViewAngle;
  modelType: string;
  pose: string;
  faceExpression: FaceExpression;
  bgCategory: BackgroundCategory;
  bgPresetId: string | null;
  bgCustomColor: string;
  bgUpload: File | null;
  bgPrompt: string;
  props: string;
  lighting: string;
  garmentDetails: string;
  fabricType: string;
  pattern: string;
  constructionDetails: string;
  hemlinePosition: HemlinePosition;
  shortKurtiStyling: ShortKurtiStyling;
}

export interface ProductState {
  image: File | null;
  imagePreview: string | null;
  mainCategory: MainProductCategory;
  subCategory: string;
  withModel: boolean;
  backgroundType: 'Studio' | 'Natural';
  lighting: string;
}
