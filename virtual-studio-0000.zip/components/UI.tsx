
import React, { useState, useEffect } from 'react';
import { 
  Upload, ChevronDown, Loader2, Camera, Check, User, 
  ArrowUp, ArrowDown, ArrowLeft, ArrowRight, ZoomIn, 
  Activity, Footprints, Armchair, Smile, Palette, Globe, Sparkles,
  UserCircle, Settings2, Image as ImageIcon, Briefcase, Smartphone, 
  Coffee, Plane, Home, Glasses, X, Lock
} from 'lucide-react';
import { ModelDef, PoseDef, ViewAngle, VIEW_ANGLES, BackgroundCategory, BackgroundPreset, BACKGROUND_PRESETS, PropCategory, PropDef, PROP_DATABASE } from '../types';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'outline';
  glow?: boolean;
  // Added size prop to resolve "Property 'size' does not exist" error
  size?: 'sm' | 'md' | 'lg';
}

export const Button: React.FC<ButtonProps> = ({ children, variant = 'primary', glow, size = 'md', className = '', ...props }) => {
  const baseStyle = "rounded-none font-display font-bold tracking-wider transition-all duration-300 uppercase flex items-center justify-center";
  
  // Implemented size-based styles
  const sizes = {
    sm: "px-4 py-2 text-xs",
    md: "px-6 py-3 text-sm",
    lg: "px-8 py-4 text-base"
  };

  const variants = {
    primary: "bg-neon-purple text-white border border-neon-purple hover:bg-transparent hover:text-neon-purple hover:shadow-[0_0_15px_#b026ff]",
    secondary: "bg-white/10 text-white backdrop-blur-md border border-white/20 hover:bg-white/20",
    outline: "border border-white/30 text-white hover:border-neon-blue hover:text-neon-blue"
  };

  return (
    <button 
      className={`${baseStyle} ${sizes[size]} ${variants[variant]} ${glow ? 'animate-glow' : ''} ${className}`}
      {...props}
    >
      {children}
    </button>
  );
};

interface FileInputProps {
  label: string;
  onChange: (file: File) => void;
  preview: string | null;
  compact?: boolean;
  isScanning?: boolean;
  analysisData?: string | null;
}

export const FileInput: React.FC<FileInputProps> = ({ label, onChange, preview, compact, isScanning, analysisData }) => {
  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      onChange(e.target.files[0]);
    }
  };

  return (
    <div className="w-full">
      <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-2 flex justify-between">
        {label}
        {analysisData && <span className="text-neon-blue animate-pulse">{analysisData}</span>}
      </label>
      <div className="flex gap-2">
        <div className="relative group cursor-pointer flex-1">
          <input 
            type="file" 
            accept="image/*" 
            onChange={handleFile}
            className="absolute inset-0 w-full h-full opacity-0 z-10 cursor-pointer"
          />
          <div className={`
            relative overflow-hidden
            border-2 border-dashed border-gray-600 rounded-lg flex flex-col items-center justify-center
            transition-colors group-hover:border-neon-blue bg-dark-card/50 backdrop-blur-sm
            ${preview ? 'border-neon-purple' : ''}
            ${compact ? 'h-24' : 'h-48'}
          `}>
            {preview ? (
              <>
                <img src={preview} alt="Preview" className="h-full w-full object-contain p-2 rounded-lg relative z-0" />
                
                {/* Scanning Effect Overlay */}
                {isScanning && (
                  <div className="absolute inset-0 z-10 pointer-events-none">
                    <div className="absolute inset-0 bg-neon-purple/10"></div>
                    <div className="absolute top-0 left-0 w-full h-1 bg-neon-purple shadow-[0_0_15px_#b026ff] animate-[scan_2s_linear_infinite]"></div>
                    <div className="absolute inset-0 bg-[linear-gradient(rgba(176,38,255,0.1)_1px,transparent_1px),linear-gradient(90deg,rgba(176,38,255,0.1)_1px,transparent_1px)] bg-[size:20px_20px] opacity-50"></div>
                    <div className="absolute bottom-2 right-2 text-[10px] font-mono text-neon-purple bg-black/80 px-2 py-1 rounded">
                      ANALYZING WEAVE...
                    </div>
                  </div>
                )}
                
                {/* Analysis Result Overlay */}
                {!isScanning && analysisData && (
                    <div className="absolute top-2 right-2 z-10">
                         <div className="bg-neon-blue/20 backdrop-blur-md border border-neon-blue/50 text-neon-blue text-[10px] font-bold px-2 py-1 rounded-full flex items-center gap-1">
                            <Check className="w-3 h-3" /> SCANNED
                         </div>
                    </div>
                )}
              </>
            ) : (
              <>
                <Upload className={`${compact ? 'w-5 h-5' : 'w-8 h-8'} text-gray-400 group-hover:text-neon-blue mb-2 transition-colors`} />
                <span className="text-gray-400 group-hover:text-white text-xs text-center px-2">{compact ? 'Upload' : 'Click or Drag to Upload'}</span>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

interface SelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  label: string;
  options: string[];
}

export const Select: React.FC<SelectProps> = ({ label, options, className = '', ...props }) => {
  return (
    <div className="w-full">
      <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">{label}</label>
      <div className="relative">
        <select 
          className={`
            w-full bg-dark-card border border-gray-700 text-white py-3 px-4 pr-10 rounded-sm appearance-none
            focus:outline-none focus:border-neon-purple focus:ring-1 focus:ring-neon-purple
            transition-all font-sans text-sm ${className}
          `} 
          {...props}
        >
          {options.map(opt => <option key={opt} value={opt}>{opt}</option>)}
        </select>
        <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" />
      </div>
    </div>
  );
};

interface SelectorGridProps {
  label: string;
  options: readonly string[];
  selected: string;
  onChange: (val: string) => void;
}

export const SelectorGrid: React.FC<SelectorGridProps> = ({ label, options, selected, onChange }) => {
  return (
    <div className="w-full">
      <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">{label}</label>
      <div className="grid grid-cols-2 gap-2">
        {options.map(opt => (
          <button
            key={opt}
            onClick={(e) => { e.preventDefault(); onChange(opt); }}
            className={`
              py-3 px-2 rounded-lg text-xs font-bold transition-all border
              ${selected === opt 
                ? 'bg-neon-purple/20 border-neon-purple text-white shadow-[0_0_10px_rgba(176,38,255,0.3)]' 
                : 'bg-dark-card border-gray-800 text-gray-500 hover:border-gray-600 hover:text-gray-300'}
            `}
          >
            {opt}
          </button>
        ))}
      </div>
    </div>
  );
};

export const PropSelector: React.FC<{
  label: string;
  selectedId: string;
  onChange: (prop: PropDef) => void;
}> = ({ label, selectedId, onChange }) => {
  const categories = Object.keys(PROP_DATABASE) as PropCategory[];
  const initialProp = Object.values(PROP_DATABASE).flat().find(p => p.id === selectedId);
  const [activeCat, setActiveCat] = useState<PropCategory>(initialProp ? initialProp.category : categories[0]);

  const getIcon = (cat: PropCategory) => {
    switch (cat) {
      case 'Bags': return <Briefcase className="w-3 h-3" />;
      case 'Tech': return <Smartphone className="w-3 h-3" />;
      case 'Lifestyle': return <Coffee className="w-3 h-3" />;
      case 'Travel': return <Plane className="w-3 h-3" />;
      case 'Studio': return <Home className="w-3 h-3" />;
      case 'Accessories': return <Glasses className="w-3 h-3" />;
      default: return <X className="w-3 h-3" />;
    }
  };

  return (
    <div className="w-full">
      <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">{label}</label>
      <div className="flex gap-1 mb-2 bg-dark-card p-1 rounded-lg overflow-x-auto no-scrollbar">
        {categories.map(cat => (
          <button 
            key={cat}
            onClick={(e) => { e.preventDefault(); setActiveCat(cat); }}
            className={`flex-1 min-w-[50px] text-[9px] py-1.5 rounded uppercase font-bold transition-all flex items-center justify-center gap-1
              ${activeCat === cat ? 'bg-white/10 text-white shadow-sm' : 'text-gray-500 hover:text-gray-300'}
            `}
          >
            {getIcon(cat)} <span className="hidden sm:inline">{cat}</span>
          </button>
        ))}
      </div>
      <div className="grid grid-cols-2 gap-2">
        {PROP_DATABASE[activeCat].map(prop => (
          <button
            key={prop.id}
            onClick={(e) => { e.preventDefault(); onChange(prop); }}
            className={`
              py-2.5 px-2 rounded-lg text-[10px] font-bold transition-all border text-center
              ${selectedId === prop.id 
                ? 'bg-neon-blue/10 border-neon-blue text-white' 
                : 'bg-dark-card border-gray-800 text-gray-500 hover:border-gray-600'}
            `}
          >
            {prop.label}
          </button>
        ))}
      </div>
    </div>
  );
};

interface ViewSelectorProps {
  label: string;
  selected: ViewAngle;
  onChange: (val: ViewAngle) => void;
  availableViews?: ViewAngle[];
}

export const ViewSelector: React.FC<ViewSelectorProps> = ({ label, selected, onChange, availableViews = VIEW_ANGLES }) => {
  const getIcon = (v: ViewAngle) => {
    switch (v) {
      case 'Front': return <ArrowDown className="w-4 h-4" />;
      case 'Back': return <ArrowUp className="w-4 h-4" />;
      case 'Left Side': return <ArrowLeft className="w-4 h-4" />;
      case 'Right Side': return <ArrowRight className="w-4 h-4" />;
      case 'Closeup': return <ZoomIn className="w-4 h-4" />;
      case 'Blouse: Front': return <UserCircle className="w-4 h-4" />;
      case 'Blouse: Back': return <Settings2 className="w-4 h-4" />;
      case 'Blouse: Sleeves': return <ImageIcon className="w-4 h-4" />;
      default: return <Camera className="w-4 h-4" />;
    }
  };

  return (
    <div className="w-full">
       <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">{label}</label>
       <div className={`grid ${availableViews.length > 5 ? 'grid-cols-4' : 'grid-cols-5'} gap-1 bg-dark-card p-1 rounded-lg`}>
          {availableViews.map(v => (
            <button
              key={v}
              onClick={() => onChange(v)}
              className={`
                flex flex-col items-center justify-center py-2 rounded transition-all group
                ${selected === v ? 'bg-white/10 text-white' : 'text-gray-500 hover:text-gray-300'}
              `}
              title={v}
            >
              <div className={`mb-1 ${selected === v ? 'text-neon-blue' : ''}`}>
                 {getIcon(v)}
              </div>
              <span className="text-[9px] font-bold uppercase truncate w-full px-1 text-center">
                 {v.includes(':') ? v.split(': ')[1] : v.split(' ')[0]}
              </span>
            </button>
          ))}
       </div>
    </div>
  );
};

interface ModelSelectorProps {
  label: string;
  selectedId: string;
  onChange: (id: string) => void;
  models: ModelDef[];
}

export const ModelSelector: React.FC<ModelSelectorProps> = ({ label, selectedId, onChange, models }) => {
    const categories = Array.from(new Set(models.map(m => m.category)));
    
    // Initialize active category based on the currently selected model to ensure sync
    const initialModel = models.find(m => m.id === selectedId);
    const [activeCat, setActiveCat] = useState<string>(initialModel ? initialModel.category : categories[0]);

    // Update active category if selectedId changes externally and it belongs to a different category
    useEffect(() => {
        const currentModel = models.find(m => m.id === selectedId);
        if (currentModel && currentModel.category !== activeCat) {
            setActiveCat(currentModel.category);
        }
    }, [selectedId, models]);

    const activeModel = models.find(m => m.id === selectedId);

    return (
        <div className="w-full">
            <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">{label}</label>
            
            <div className="flex gap-1 mb-2 bg-dark-card p-1 rounded-lg overflow-x-auto no-scrollbar">
                {categories.map(cat => (
                    <button 
                        key={cat}
                        onClick={(e) => {
                          e.preventDefault(); // Prevent accidental form submission triggers
                          setActiveCat(cat);
                        }}
                        className={`flex-1 min-w-[50px] text-[10px] py-2 rounded uppercase tracking-wider font-bold transition-all
                            ${activeCat === cat ? 'bg-white/10 text-white shadow-sm' : 'text-gray-500 hover:text-gray-300'}
                        `}
                    >
                        {cat}
                    </button>
                ))}
            </div>

            <div className="grid grid-cols-5 gap-2">
                {models.filter(m => m.category === activeCat).map(model => (
                    <button
                        key={model.id}
                        onClick={(e) => {
                           e.preventDefault();
                           onChange(model.id);
                        }}
                        className={`
                            group relative aspect-square rounded-full flex flex-col items-center justify-center
                            border-2 transition-all hover:scale-105 overflow-hidden
                            ${selectedId === model.id ? 'border-neon-purple shadow-[0_0_10px_#b026ff]' : 'border-transparent hover:border-gray-600'}
                        `}
                    >
                        {/* Avatar Image */}
                        <div className="w-full h-full">
                           <img 
                              src={model.avatar} 
                              alt={model.label} 
                              className="w-full h-full object-cover"
                              onError={(e) => {
                                 // Fallback if image fails
                                 (e.target as HTMLImageElement).style.display = 'none';
                                 (e.target as HTMLImageElement).nextElementSibling?.classList.remove('hidden');
                              }}
                           />
                           {/* Fallback color circle */}
                           <div 
                              className="hidden w-full h-full flex items-center justify-center text-black/50 font-bold text-xs"
                              style={{ backgroundColor: model.colorHex }}
                           >
                                <User className="w-5 h-5 opacity-70" strokeWidth={2.5} />
                           </div>
                        </div>
                        
                        {selectedId === model.id && (
                           <div className="absolute top-0 right-0 bg-neon-purple rounded-bl-lg p-0.5 z-10">
                              <Check className="w-2 h-2 text-white" />
                           </div>
                        )}

                        {/* Tooltip */}
                        <div className="absolute -bottom-10 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity bg-black/95 border border-gray-800 text-white text-[10px] px-2 py-1 rounded w-32 z-20 pointer-events-none text-center leading-tight">
                            <span className="font-bold block text-neon-blue">{model.label}</span>
                            <span className="text-gray-400 line-clamp-2">{model.description}</span>
                        </div>
                    </button>
                ))}
            </div>
            
            {activeModel && activeModel.category === activeCat && (
              <div className="mt-3 p-3 bg-dark-card border border-white/5 rounded text-[11px] text-gray-400">
                 <div className="flex justify-between items-center mb-1">
                    <strong className="text-white">{activeModel.label}</strong>
                    <span className="text-[9px] bg-white/5 px-1.5 py-0.5 rounded border border-white/10 uppercase">Identity Locked</span>
                 </div>
                 <p className="line-clamp-3 leading-relaxed text-gray-500 italic">
                    DNA: {activeModel.physicalDescription}
                 </p>
              </div>
            )}
        </div>
    )
}

interface PoseSelectorProps {
  label: string;
  selectedId: string;
  onChange: (id: string) => void;
  poses: PoseDef[];
}

export const PoseSelector: React.FC<PoseSelectorProps> = ({ label, selectedId, onChange, poses }) => {
  const getPoseIcon = (type: PoseDef['iconType']) => {
    const props = { className: "w-5 h-5" }; 
    switch (type) {
      case 'walk': return <Footprints {...props} />;
      case 'sit': return <Armchair {...props} />;
      case 'jump': return <Activity {...props} />;
      case 'face': return <Smile {...props} />;
      default: return <User {...props} />;
    }
  };

  const categories = Array.from(new Set(poses.map(p => p.category)));
  
  const initialPose = poses.find(p => p.id === selectedId);
  const [activeCat, setActiveCat] = useState<string>(initialPose ? initialPose.category : categories[0]);

  useEffect(() => {
    const currentPose = poses.find(p => p.id === selectedId);
    if(currentPose && currentPose.category !== activeCat) {
        setActiveCat(currentPose.category);
    }
  }, [selectedId, poses]);

  return (
    <div className="w-full">
      <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">{label}</label>

      {/* Category Tabs */}
      <div className="flex gap-1 mb-3 bg-dark-card p-1 rounded-lg overflow-x-auto no-scrollbar">
          {categories.map(cat => (
              <button 
                  key={cat}
                  onClick={(e) => {
                      e.preventDefault();
                      setActiveCat(cat);
                  }}
                  className={`flex-1 min-w-[50px] text-[10px] py-2 rounded uppercase tracking-wider font-bold transition-all
                      ${activeCat === cat ? 'bg-white/10 text-white shadow-sm' : 'text-gray-500 hover:text-gray-300'}
                  `}
              >
                  {cat}
              </button>
          ))}
      </div>

      <div className="grid grid-cols-4 gap-3">
        {poses.filter(p => p.category === activeCat).map(pose => (
          <button
            key={pose.id}
            onClick={(e) => {
                e.preventDefault();
                onChange(pose.id);
            }}
            className="group flex flex-col items-center justify-center gap-2"
          >
             {/* Techy Icon Container */}
             <div className="relative w-12 h-12 flex items-center justify-center">
                {/* Outer Ring - Rotates on hover/select */}
                <div className={`
                    absolute inset-0 border border-gray-700 rounded-lg transform rotate-45 transition-all duration-500
                    ${selectedId === pose.id ? 'border-neon-blue bg-neon-blue/10 rotate-90 scale-100' : 'group-hover:rotate-12 group-hover:border-gray-500'}
                `}></div>
                
                {/* Inner Glow for Selected */}
                {selectedId === pose.id && (
                    <div className="absolute inset-0 bg-neon-blue/20 blur-md rounded-full animate-pulse"></div>
                )}

                {/* The Icon */}
                <div className={`relative z-10 transition-colors duration-300 ${selectedId === pose.id ? 'text-neon-blue' : 'text-gray-400 group-hover:text-white'}`}>
                    {getPoseIcon(pose.iconType)}
                </div>

                {/* Cyberpunk Accents */}
                <div className={`absolute -top-1 left-1/2 -translate-x-1/2 w-0.5 h-1 bg-current rounded-full transition-opacity ${selectedId === pose.id ? 'opacity-100 text-neon-blue' : 'opacity-0'}`}></div>
                <div className={`absolute -bottom-1 left-1/2 -translate-x-1/2 w-0.5 h-1 bg-current rounded-full transition-opacity ${selectedId === pose.id ? 'opacity-100 text-neon-blue' : 'opacity-0'}`}></div>
             </div>
             
             <span className={`text-[9px] font-bold text-center leading-tight uppercase transition-colors ${selectedId === pose.id ? 'text-neon-blue' : 'text-gray-500'}`}>
                {pose.label}
             </span>
          </button>
        ))}
      </div>
    </div>
  );
};


// --- BACKGROUND SELECTOR ---

interface BackgroundSelectorProps {
  label: string;
  activeCategory: BackgroundCategory;
  onCategoryChange: (cat: BackgroundCategory) => void;
  selectedPresetId: string | null;
  onPresetSelect: (preset: BackgroundPreset) => void;
  customColor: string;
  onCustomColorChange: (color: string) => void;
  onUpload: (file: File) => void;
}

export const BackgroundSelector: React.FC<BackgroundSelectorProps> = ({
  label, activeCategory, onCategoryChange, selectedPresetId, onPresetSelect, customColor, onCustomColorChange, onUpload
}) => {
  const categories: {id: BackgroundCategory, icon: React.ReactNode}[] = [
    { id: 'Solid', icon: <Palette className="w-3 h-3" /> },
    { id: 'Outdoor', icon: <Globe className="w-3 h-3" /> },
    { id: 'Creative', icon: <Sparkles className="w-3 h-3" /> },
    { id: 'Upload', icon: <Upload className="w-3 h-3" /> }
  ];

  return (
    <div className="w-full">
      <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">{label}</label>
      
      {/* Tabs */}
      <div className="flex gap-1 mb-3 bg-dark-card p-1 rounded-lg">
         {categories.map(cat => (
            <button
               key={cat.id}
               onClick={(e) => { e.preventDefault(); onCategoryChange(cat.id); }}
               className={`flex-1 py-2 rounded flex items-center justify-center gap-1 text-[10px] uppercase font-bold tracking-wide transition-all
                  ${activeCategory === cat.id ? 'bg-white/10 text-white' : 'text-gray-500 hover:text-gray-300'}
               `}
            >
               {cat.icon} {cat.id}
            </button>
         ))}
      </div>

      {/* Content Area */}
      <div className="bg-dark-card p-2 rounded-lg border border-gray-800 min-h-[120px]">
         {activeCategory === 'Upload' ? (
            <FileInput 
               label="" 
               compact 
               preview={null} 
               onChange={onUpload} 
            />
         ) : (
            <div className="grid grid-cols-3 gap-2">
               {BACKGROUND_PRESETS[activeCategory].map(preset => (
                  <button
                     key={preset.id}
                     onClick={(e) => { e.preventDefault(); onPresetSelect(preset); }}
                     className={`
                        relative aspect-square rounded overflow-hidden border-2 transition-all group
                        ${selectedPresetId === preset.id ? 'border-neon-purple shadow-[0_0_10px_#b026ff]' : 'border-transparent hover:border-gray-600'}
                     `}
                  >
                     {preset.isColor ? (
                        <div className="w-full h-full" style={{ backgroundColor: preset.src }}></div>
                     ) : (
                        <img src={preset.src} alt={preset.label} className="w-full h-full object-cover" />
                     )}
                     
                     <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                         <span className="text-[9px] text-white font-bold text-center px-1">{preset.label}</span>
                     </div>
                     
                     {selectedPresetId === preset.id && (
                        <div className="absolute top-1 right-1 bg-neon-purple rounded-full p-0.5">
                           <Check className="w-2 h-2 text-white" />
                        </div>
                     )}
                  </button>
               ))}
               
               {/* Custom Color Picker for Solid Tab */}
               {activeCategory === 'Solid' && (
                  <div className="relative aspect-square rounded overflow-hidden border-2 border-dashed border-gray-700 hover:border-gray-500 flex flex-col items-center justify-center">
                     <input 
                        type="color" 
                        value={customColor}
                        onChange={(e) => onCustomColorChange(e.target.value)}
                        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                     />
                     <Palette className="w-6 h-6 text-gray-500 mb-1" />
                     <span className="text-[9px] text-gray-500 font-bold uppercase">Custom</span>
                     <div className="w-4 h-4 rounded-full border border-gray-500 mt-1" style={{backgroundColor: customColor}}></div>
                  </div>
               )}
            </div>
         )}
      </div>
    </div>
  );
};


export const LoadingOverlay: React.FC<{ message: string }> = ({ message }) => {
  return (
    <div className="absolute inset-0 z-50 flex flex-col items-center justify-center bg-black/90 backdrop-blur-lg">
      <div className="relative w-24 h-24 flex items-center justify-center mb-8">
        <div className="absolute inset-0 rounded-full border-4 border-neon-purple/30 animate-[spin_3s_linear_infinite]"></div>
        <div className="absolute inset-2 rounded-full border-4 border-neon-blue/30 animate-[spin_2s_linear_infinite_reverse]"></div>
        <Loader2 className="w-10 h-10 text-white animate-spin" />
      </div>
      <h2 className="text-2xl font-display font-bold text-white tracking-widest animate-pulse mb-2">GENERATING</h2>
      <p className="text-neon-blue font-mono text-sm">{message}</p>
      
      {/* Scanning Effect Bar */}
      <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-neon-purple to-transparent animate-[shimmer_2s_infinite]"></div>
    </div>
  );
};
