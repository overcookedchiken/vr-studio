
import { createClient } from 'https://aistudiocdn.com/@supabase/supabase-js@^2.48.1';

/**
 * Live Supabase client initialization.
 * Connects to the user's provided backend for authentication and data management.
 */

const supabaseUrl = 'https://cpqgdflrwayksqtpkpoo.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNwcWdkZmxyd2F5a3NxdHBrcG9vIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjU3MjcyMjgsImV4cCI6MjA4MTMwMzIyOH0.odUtWbnIR8nEaHMIPl8UsJZaFc1RSsg6G9HBgD_sEV8';

// Create and export the authenticated Supabase client
export const supabase = createClient(supabaseUrl, supabaseAnonKey);
