
// DEPRECATED: This project now uses Supabase for Authentication and Database.
// Please refer to supabaseClient.ts and App.tsx for the current implementation.
// This file can be safely deleted.

export {};
