
import React, { useState, useEffect, useCallback } from 'react';
import { 
  Layers, PlusCircle, ArrowLeft, Download, Maximize2, ImageIcon, Shirt, Box, Lock, 
  Check, Trash2, Copy, Palette, Globe, Sparkles, Upload, Plus, X, Loader2, Mail, 
  User as UserIcon, LogOut, Shield, HardDrive, Zap, ChevronRight, Settings, Bell, 
  CreditCard, Key, Search, Menu, ExternalLink, RefreshCw
} from 'lucide-react';
import { 
  StudioTab, FashionState, ProductState, Project,
  MODEL_DATABASE, POSE_DATABASE, LIGHTING_OPTIONS, BACKGROUND_PRESETS,
  MainGarmentCategory, GARMENT_HIERARCHY, FACE_EXPRESSIONS,
  PRODUCT_HIERARCHY, VIEW_ANGLES, ViewAngle,
  PROP_DATABASE, BOTTOM_DATABASE, HemlinePosition, ShortKurtiStyling, AdditionalLayer
} from './types';
import { generateStudioImage, analyzeGarmentImage } from './services/geminiService';
import { Button, FileInput, Select, LoadingOverlay, ModelSelector, ViewSelector, PoseSelector, BackgroundSelector, SelectorGrid, PropSelector } from './components/UI';
import { supabase } from './supabaseClient';
import { User } from 'https://aistudiocdn.com/@supabase/supabase-js@^2.48.1';

// --- INITIAL STATES ---

const INITIAL_FASHION: FashionState = {
  mainCategory: 'Western Wear',
  subCategory: GARMENT_HIERARCHY['Western Wear'][0],
  image: null,
  imagePreview: null,
  backImage: null,
  backImagePreview: null,
  additionalLayers: [],
  bottomType: 'none',
  bottomImage: null,
  bottomImagePreview: null,
  selectedBottomId: BOTTOM_DATABASE[0].id,
  view: 'Front',
  modelType: MODEL_DATABASE[0].id,
  pose: POSE_DATABASE[0].id,
  faceExpression: FACE_EXPRESSIONS[0],
  bgCategory: 'Solid',
  bgPresetId: 'bg_white',
  bgCustomColor: '#ffffff',
  bgUpload: null,
  bgPrompt: BACKGROUND_PRESETS['Solid'][0].prompt,
  props: PROP_DATABASE['None'][0].id,
  lighting: LIGHTING_OPTIONS[0],
  garmentDetails: '',
  fabricType: '',
  pattern: '',
  constructionDetails: '',
  hemlinePosition: 'top of hip bone',
  shortKurtiStyling: 'Straight Fit'
};

const INITIAL_PRODUCT: ProductState = {
  image: null,
  imagePreview: null,
  mainCategory: 'Cosmetics & Beauty',
  subCategory: PRODUCT_HIERARCHY['Cosmetics & Beauty'][0],
  withModel: false,
  backgroundType: 'Studio',
  lighting: LIGHTING_OPTIONS[0],
};

type ViewState = 'LANDING' | 'AUTH' | 'DASHBOARD' | 'CREATE_PROJECT' | 'STUDIO' | 'PROFILE';

const StepSection: React.FC<{
  title: string;
  isLocked: boolean;
  children: React.ReactNode;
  className?: string;
}> = ({ title, isLocked, children, className = '' }) => {
  return (
    <div className={`relative transition-all duration-500 ${className} ${isLocked ? 'opacity-50 grayscale pointer-events-none select-none' : 'opacity-100 grayscale-0'}`}>
      {isLocked && (
        <div className="absolute inset-0 z-10 flex items-center justify-center">
           <div className="bg-black/50 p-2 rounded-full backdrop-blur-sm border border-white/10">
              <Lock className="w-4 h-4 text-gray-400" />
           </div>
        </div>
      )}
      <div className="mb-2 flex items-center gap-2">
         <span className={`text-xs font-bold uppercase tracking-widest ${isLocked ? 'text-gray-600' : 'text-neon-blue'}`}>
            {title}
         </span>
      </div>
      {children}
    </div>
  );
};

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<ViewState>('LANDING');
  const [user, setUser] = useState<User | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [authMode, setAuthMode] = useState<'LOGIN' | 'SIGNUP'>('LOGIN');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [authError, setAuthError] = useState<string | null>(null);

  const [activeProject, setActiveProject] = useState<Project | null>(null);
  const [projects, setProjects] = useState<Project[]>([]);
  const [projectImages, setProjectImages] = useState<{id: string, image: string}[]>([]); 

  const [newProjectName, setNewProjectName] = useState('');
  const [newProjectType, setNewProjectType] = useState<StudioTab>(StudioTab.FASHION);
  const [dashboardFilter, setDashboardFilter] = useState<'ALL' | 'FASHION' | 'PRODUCT'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  const [activeTab, setActiveTab] = useState<StudioTab>(StudioTab.FASHION);
  const [fashionState, setFashionState] = useState<FashionState>(INITIAL_FASHION);
  const [productState, setProductState] = useState<ProductState>(INITIAL_PRODUCT);
  
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisData, setAnalysisData] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isLoadingData, setIsLoadingData] = useState(false);
  const [isRefreshingHistory, setIsRefreshingHistory] = useState(false);
  
  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  const fetchUserProjects = useCallback(async () => {
    if (!user) return;
    setIsLoadingData(true);
    try {
      const { data, error } = await supabase
        .from('projects')
        .select('*')
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      
      const mappedProjects: Project[] = (data || []).map((p: any) => ({
        id: p.id,
        name: p.name,
        image: p.thumbnail_url || 'https://images.unsplash.com/photo-1523381210434-271e8be1f52b?q=80&w=400',
        type: p.type as 'FASHION' | 'PRODUCT',
        timestamp: new Date(p.created_at).getTime()
      }));
      setProjects(mappedProjects);
    } catch (err) {
      console.error("Error fetching projects:", err);
    } finally {
      setIsLoadingData(false);
    }
  }, [user]);

  const fetchProjectGenerations = useCallback(async (projectId: string) => {
    setIsRefreshingHistory(true);
    try {
      const { data, error } = await supabase
        .from('generations')
        .select('*')
        .eq('project_id', projectId)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      
      const images = (data || []).map((g: any) => ({
        id: g.id,
        image: g.image_url
      }));
      setProjectImages(images);
      
      // Update selected image to latest generation if available
      if (images.length > 0 && !isGenerating) {
        setSelectedImage(images[0].image);
      }
    } catch (err) {
      console.error("Error fetching generations:", err);
    } finally {
      setIsRefreshingHistory(false);
    }
  }, [isGenerating]);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
      setAuthLoading(false);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
    });

    return () => subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (user) fetchUserProjects();
    else {
      setProjects([]);
      setActiveProject(null);
    }
  }, [user, fetchUserProjects]);

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    setAuthLoading(true);

    try {
      if (authMode === 'LOGIN') {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
      } else {
        const { error } = await supabase.auth.signUp({
          email, password,
          options: { data: { full_name: email.split('@')[0] } }
        });
        if (error) throw error;
        alert("Verification email sent (if configured). You can now attempt to login.");
        setAuthMode('LOGIN');
      }
      setCurrentView('DASHBOARD');
      setEmail('');
      setPassword('');
    } catch (err: any) {
      setAuthError(err.message || "Authentication failed");
    } finally {
      setAuthLoading(false);
    }
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    setCurrentView('LANDING');
  };

  const handleDeleteProject = async (id: string) => {
    if (!confirm("Permanently delete this project?")) return;
    
    try {
      const { error } = await supabase.from('projects').delete().eq('id', id);
      if (error) throw error;
      setProjects(prev => prev.filter(p => p.id !== id));
      if (activeProject?.id === id) setActiveProject(null);
    } catch (err) {
      console.error("Delete failed:", err);
    }
  };

  const handleCreateProject = async () => {
    if (!newProjectName || !user) return;
    
    try {
      const { data, error } = await supabase
        .from('projects')
        .insert({
          user_id: user.id,
          name: newProjectName,
          type: newProjectType,
          thumbnail_url: 'https://images.unsplash.com/photo-1523381210434-271e8be1f52b?q=80&w=400'
        })
        .select()
        .single();
      
      if (error) throw error;

      const project: Project = {
        id: data.id,
        name: data.name,
        image: data.thumbnail_url,
        type: data.type as 'FASHION' | 'PRODUCT',
        timestamp: new Date(data.created_at).getTime()
      };

      setProjects(prev => [project, ...prev]);
      setActiveProject(project);
      setActiveTab(newProjectType);
      setFashionState(INITIAL_FASHION);
      setProductState(INITIAL_PRODUCT);
      setProjectImages([]);
      setSelectedImage(null);
      setCurrentView('STUDIO');
      setNewProjectName('');
    } catch (err) {
      console.error("Project creation failed:", err);
    }
  };

  const handleOpenProjectInStudio = (project: Project) => {
      setActiveProject(project);
      setActiveTab(project.type as StudioTab);
      setProjectImages([]);
      setSelectedImage(project.image);
      fetchProjectGenerations(project.id);
      setCurrentView('STUDIO');
  };

  const handleFashionImageUpload = async (file: File, type: 'front' | 'back' | 'bottom') => {
     if (type === 'front') {
        setFashionState(prev => ({ ...prev, image: file, imagePreview: URL.createObjectURL(file) }));
        setIsAnalyzing(true);
        setAnalysisData("AI Scanning Weave & Cut...");
        try {
            const analysis = await analyzeGarmentImage(file);
            let mainCat = analysis.mainCategory as MainGarmentCategory;
            let subCat = analysis.subCategory;
            
            if (!GARMENT_HIERARCHY[mainCat]) mainCat = 'Western Wear'; 
            if (!GARMENT_HIERARCHY[mainCat].includes(subCat)) {
                const otherCat = mainCat === 'Western Wear' ? 'Ethnic Wear' : 'Western Wear';
                if (GARMENT_HIERARCHY[otherCat].includes(subCat)) {
                   mainCat = otherCat;
                } else {
                   subCat = GARMENT_HIERARCHY[mainCat][0];
                }
            }
            
            setFashionState(prev => ({ 
              ...prev, 
              mainCategory: mainCat, 
              subCategory: subCat,
              fabricType: analysis.fabricType,
              pattern: analysis.pattern,
              constructionDetails: analysis.constructionDetails,
              hemlinePosition: analysis.hemlinePosition,
              shortKurtiStyling: analysis.shortKurtiStyling
            }));
            setAnalysisData("Analysis Complete");
        } catch (error) {
            console.error("Analysis failed:", error);
            setAnalysisData("Manual check needed");
        } finally {
            setIsAnalyzing(false);
        }
     }
  };

  const handleGenerate = async () => {
    if (!activeProject?.id) return;
    setIsGenerating(true);
    try {
      const result = await generateStudioImage(activeTab, activeTab === StudioTab.FASHION ? fashionState : productState);
      
      const { data, error } = await supabase
        .from('generations')
        .insert({
          project_id: activeProject.id,
          image_url: result,
          settings: activeTab === StudioTab.FASHION 
            ? { ...fashionState, image: null, imagePreview: null, backImage: null, backImagePreview: null } 
            : { ...productState, image: null, imagePreview: null }
        })
        .select()
        .single();
      
      if (error) throw error;

      const newGen = { id: data.id, image: result };
      setProjectImages(prev => [newGen, ...prev]);
      setSelectedImage(result);
      
      await supabase.from('projects').update({ thumbnail_url: result }).eq('id', activeProject.id);
      setProjects(prev => prev.map(p => p.id === activeProject.id ? { ...p, image: result } : p));
      
    } catch (err: any) {
      alert(`Generation failed: ${err.message}`);
    } finally {
      setIsGenerating(false);
    }
  };

  if (authLoading) return (
    <div className="h-screen bg-black flex items-center justify-center">
      <Loader2 className="w-8 h-8 text-neon-purple animate-spin" />
    </div>
  );

  const renderLanding = () => (
    <div className="min-h-screen flex flex-col items-center justify-center p-6 text-center">
      <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-10 duration-1000">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-neon-purple/10 border border-neon-purple/20 text-neon-purple text-xs font-bold uppercase tracking-widest mb-4">
          <Zap className="w-3 h-3" /> Hyper-Realistic AI Production
        </div>
        <h1 className="text-6xl md:text-8xl font-display font-black text-white tracking-tighter leading-none">
          VIRTUAL <span className="text-transparent bg-clip-text bg-gradient-to-r from-neon-purple to-neon-blue">STUDIO</span>
        </h1>
        <p className="text-xl text-gray-400 max-w-2xl mx-auto font-light leading-relaxed">
          The ultimate AGI-powered engine for fashion and product photography. 
          Generate hyper-realistic catalogs from flat lays in seconds.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center mt-12">
          <Button size="lg" glow onClick={() => (user ? setCurrentView('DASHBOARD') : setCurrentView('AUTH'))}>
            {user ? 'Go to Dashboard' : 'Get Started'} <ChevronRight className="ml-2 w-5 h-5" />
          </Button>
          <Button variant="outline" size="lg">View Showcase</Button>
        </div>
      </div>
    </div>
  );

  const renderAuth = () => (
    <div className="min-h-screen flex items-center justify-center p-6">
      <div className="w-full max-w-md bg-dark-card border border-white/10 rounded-2xl p-8 space-y-6 shadow-2xl backdrop-blur-xl">
        <div className="text-center space-y-2">
          <h2 className="text-2xl font-display font-bold text-white uppercase tracking-widest">
            {authMode === 'LOGIN' ? 'Welcome Back' : 'Join the Future'}
          </h2>
          <p className="text-gray-500 text-sm">Enter your credentials to access the studio</p>
        </div>

        {authError && (
          <div className="bg-red-500/10 border border-red-500/50 text-red-500 text-xs p-3 rounded-lg flex items-center gap-2">
            <Shield className="w-4 h-4" /> {authError}
          </div>
        )}

        <form onSubmit={handleAuth} className="space-y-4">
          <div className="space-y-1">
            <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest ml-1">Email Address</label>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
              <input 
                type="email" 
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-black/50 border border-white/10 rounded-xl py-3 pl-10 pr-4 text-white focus:outline-none focus:border-neon-purple transition-all"
                placeholder="design@studio.ai"
              />
            </div>
          </div>
          <div className="space-y-1">
            <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest ml-1">Password</label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
              <input 
                type="password" 
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-black/50 border border-white/10 rounded-xl py-3 pl-10 pr-4 text-white focus:outline-none focus:border-neon-purple transition-all"
                placeholder="••••••••"
              />
            </div>
          </div>
          <Button className="w-full py-4 rounded-xl" disabled={authLoading}>
            {authLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : (authMode === 'LOGIN' ? 'Secure Login' : 'Create Account')}
          </Button>
        </form>

        <div className="text-center">
          <button 
            onClick={() => setAuthMode(authMode === 'LOGIN' ? 'SIGNUP' : 'LOGIN')}
            className="text-xs text-gray-500 hover:text-neon-blue transition-colors"
          >
            {authMode === 'LOGIN' ? "Don't have an account? Sign up" : "Already have an account? Login"}
          </button>
        </div>
      </div>
    </div>
  );

  const renderDashboard = () => (
    <div className="min-h-screen bg-dark-bg text-white">
      <nav className="h-16 border-b border-white/5 px-8 flex items-center justify-between sticky top-0 bg-dark-bg/80 backdrop-blur-md z-40">
        <h1 className="font-display font-black text-xl tracking-tighter cursor-pointer" onClick={() => setCurrentView('LANDING')}>
          VIRTUAL<span className="text-neon-purple">STUDIO</span>
        </h1>
        <div className="flex items-center gap-4">
          <div className="h-8 w-8 rounded-full bg-neon-purple flex items-center justify-center text-xs font-bold">
            {user?.email?.[0].toUpperCase()}
          </div>
          <button onClick={handleLogout} className="p-2 text-gray-400 hover:text-red-500 transition-colors"><LogOut className="w-5 h-5" /></button>
        </div>
      </nav>

      <main className="p-8 max-w-7xl mx-auto space-y-8">
        <div className="flex justify-between items-center">
          <div>
            <h2 className="text-3xl font-display font-bold">My Projects</h2>
            <p className="text-gray-500">Manage your hyper-realistic productions</p>
          </div>
          <Button onClick={() => setCurrentView('CREATE_PROJECT')} className="rounded-xl px-8">
            <Plus className="w-5 h-5 mr-2" /> New Project
          </Button>
        </div>

        {isLoadingData ? (
          <div className="h-64 flex items-center justify-center"><Loader2 className="w-8 h-8 text-neon-purple animate-spin" /></div>
        ) : projects.length === 0 ? (
          <div className="h-96 border-2 border-dashed border-white/5 rounded-3xl flex flex-col items-center justify-center text-center space-y-4">
            <Box className="w-8 h-8 text-gray-600" />
            <p className="text-gray-500">No projects yet. Start your first AI production.</p>
            <Button variant="secondary" onClick={() => setCurrentView('CREATE_PROJECT')}>Create Project</Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {projects.map(project => (
              <div 
                key={project.id} 
                onClick={() => handleOpenProjectInStudio(project)}
                className="group relative bg-dark-card border border-white/5 rounded-2xl overflow-hidden hover:border-neon-purple/50 transition-all cursor-pointer shadow-xl"
              >
                <div className="aspect-[3/4] overflow-hidden">
                  <img src={project.image} alt={project.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent p-4 flex flex-col justify-end">
                  <span className="text-[10px] font-bold uppercase text-neon-blue mb-1">{project.type}</span>
                  <h3 className="text-white font-bold truncate">{project.name}</h3>
                </div>
                <button onClick={(e) => { e.stopPropagation(); handleDeleteProject(project.id); }} className="absolute top-3 right-3 p-2 bg-black/50 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity hover:bg-red-500"><Trash2 className="w-4 h-4" /></button>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );

  const renderCreateProjectModal = () => (
    <div className="min-h-screen flex items-center justify-center p-6">
       <div className="w-full max-w-xl bg-dark-card border border-white/10 rounded-2xl p-10 space-y-8 shadow-2xl">
          <div className="flex items-center justify-between">
            <h2 className="text-3xl font-display font-bold">New Project</h2>
            <button onClick={() => setCurrentView('DASHBOARD')} className="p-2 hover:bg-white/5 rounded-full"><X className="w-6 h-6" /></button>
          </div>
          <div className="space-y-6">
             <div className="space-y-2">
                <label className="text-xs font-bold text-gray-500 uppercase tracking-widest">Project Name</label>
                <input 
                  type="text" 
                  autoFocus
                  value={newProjectName}
                  onChange={(e) => setNewProjectName(e.target.value)}
                  placeholder="Spring Collection 2025..."
                  className="w-full bg-white/5 border border-white/10 rounded-xl py-4 px-6 text-xl focus:border-neon-purple transition-all outline-none"
                />
             </div>
             <div className="grid grid-cols-2 gap-4">
                <button onClick={() => setNewProjectType(StudioTab.FASHION)} className={`p-6 rounded-2xl border-2 text-left ${newProjectType === StudioTab.FASHION ? 'border-neon-purple bg-neon-purple/5' : 'border-white/5 bg-white/5'}`}>
                  <Shirt className={`w-8 h-8 mb-4 ${newProjectType === StudioTab.FASHION ? 'text-neon-purple' : 'text-gray-500'}`} />
                  <h3 className="font-bold">Fashion</h3>
                </button>
                <button onClick={() => setNewProjectType(StudioTab.PRODUCT)} className={`p-6 rounded-2xl border-2 text-left ${newProjectType === StudioTab.PRODUCT ? 'border-neon-blue bg-neon-blue/5' : 'border-white/5 bg-white/5'}`}>
                  <Box className={`w-8 h-8 mb-4 ${newProjectType === StudioTab.PRODUCT ? 'text-neon-blue' : 'text-gray-500'}`} />
                  <h3 className="font-bold">Product</h3>
                </button>
             </div>
          </div>
          <div className="flex gap-4">
             <Button variant="secondary" className="flex-1" onClick={() => setCurrentView('DASHBOARD')}>Cancel</Button>
             <Button className="flex-1" onClick={handleCreateProject} disabled={!newProjectName}>Launch</Button>
          </div>
       </div>
    </div>
  );

  const renderStudio = () => (
    <div className="h-screen bg-dark-bg flex flex-col overflow-hidden">
      <header className="h-14 border-b border-white/5 px-6 flex items-center justify-between shrink-0 bg-dark-bg/50 backdrop-blur-sm z-30">
        <div className="flex items-center gap-4">
          <button onClick={() => setCurrentView('DASHBOARD')} className="p-2 hover:bg-white/5 rounded-lg transition-colors"><ArrowLeft className="w-5 h-5" /></button>
          <div>
             <h1 className="font-display font-bold text-sm tracking-widest uppercase">{activeProject?.name}</h1>
             <div className="text-[10px] text-gray-500 uppercase font-bold tracking-tighter">
                <span className="text-neon-purple">{activeTab} STUDIO</span>
             </div>
          </div>
        </div>
        <Button variant="primary" className="py-2 h-9 px-4 rounded-lg flex items-center gap-2" glow onClick={handleGenerate} disabled={isGenerating}>
           {isGenerating ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
           {isGenerating ? 'Synthesizing...' : 'Generate'}
        </Button>
      </header>

      <div className="flex-1 flex overflow-hidden">
        <aside className="w-80 border-r border-white/5 overflow-y-auto no-scrollbar bg-dark-card/30 p-5 space-y-8">
           {activeTab === StudioTab.FASHION ? (
             <>
               <StepSection title="01. Input Garment" isLocked={false}>
                  <FileInput 
                    label="Front View" 
                    onChange={(f) => handleFashionImageUpload(f, 'front')} 
                    preview={fashionState.imagePreview}
                    isScanning={isAnalyzing}
                    analysisData={analysisData}
                  />
               </StepSection>
               <StepSection title="02. Model Identity" isLocked={!fashionState.image}>
                  <ModelSelector label="Choose Model" selectedId={fashionState.modelType} onChange={(id) => setFashionState(prev => ({...prev, modelType: id}))} models={MODEL_DATABASE} />
               </StepSection>
               <StepSection title="03. Composition" isLocked={!fashionState.image}>
                  <div className="space-y-4">
                    <ViewSelector label="Angle" selected={fashionState.view} onChange={(v) => setFashionState(prev => ({...prev, view: v}))} />
                    <PoseSelector label="Pose" selectedId={fashionState.pose} onChange={(id) => setFashionState(prev => ({...prev, pose: id}))} poses={POSE_DATABASE} />
                  </div>
               </StepSection>
               <StepSection title="04. Backdrop" isLocked={!fashionState.image}>
                  <BackgroundSelector 
                    label="Backdrop" 
                    activeCategory={fashionState.bgCategory} 
                    onCategoryChange={(c) => setFashionState(prev => ({...prev, bgCategory: c}))} 
                    selectedPresetId={fashionState.bgPresetId} 
                    onPresetSelect={(p) => setFashionState(prev => ({...prev, bgPresetId: p.id, bgPrompt: p.prompt}))} 
                    customColor={fashionState.bgCustomColor} 
                    onCustomColorChange={(c) => setFashionState(prev => ({...prev, bgCustomColor: c}))} 
                    onUpload={(f) => setFashionState(prev => ({...prev, bgUpload: f}))} 
                  />
               </StepSection>
             </>
           ) : (
             <StepSection title="01. Product Input" isLocked={false}>
                 <FileInput label="Upload Product" onChange={(f) => setProductState(prev => ({...prev, image: f, imagePreview: URL.createObjectURL(f)}))} preview={productState.imagePreview} />
                 <div className="mt-4">
                    <SelectorGrid label="Category" options={Object.keys(PRODUCT_HIERARCHY)} selected={productState.mainCategory} onChange={(v) => setProductState(prev => ({...prev, mainCategory: v as any, subCategory: PRODUCT_HIERARCHY[v as any][0]}))} />
                 </div>
             </StepSection>
           )}
        </aside>

        <main className="flex-1 relative flex flex-col bg-black overflow-hidden">
           <div className="flex-1 relative p-8 flex items-center justify-center">
              {isGenerating && <LoadingOverlay message="Synthesizing pixels..." />}
              {!selectedImage ? (
                <div className="text-center space-y-4">
                   <ImageIcon className="w-16 h-16 text-gray-800 mx-auto" />
                   <p className="text-gray-600 uppercase font-bold text-xs">Waiting for input</p>
                </div>
              ) : (
                <div className="relative group max-h-full aspect-[3/4] shadow-2xl rounded-xl overflow-hidden border border-white/10">
                   <img src={selectedImage} alt="Render" className="h-full w-full object-contain" />
                   <button className="absolute bottom-6 right-6 p-3 bg-white text-black rounded-full opacity-0 group-hover:opacity-100 transition-opacity" onClick={() => window.open(selectedImage, '_blank')}><Download /></button>
                </div>
              )}
           </div>

           <div className="h-28 border-t border-white/5 px-6 flex items-center gap-4 bg-dark-card/50 backdrop-blur-md overflow-x-auto no-scrollbar">
              <div className="flex items-center gap-2 shrink-0 pr-4">
                 <button onClick={() => activeProject && fetchProjectGenerations(activeProject.id)} className="p-2 hover:bg-white/5 rounded-full"><RefreshCw className={`w-4 h-4 text-gray-500 ${isRefreshingHistory ? 'animate-spin' : ''}`} /></button>
              </div>
              <div className="flex gap-4">
                 {projectImages.map((img) => (
                    <button key={img.id} onClick={() => setSelectedImage(img.image)} className={`relative aspect-square h-20 rounded-lg overflow-hidden border-2 transition-all ${selectedImage === img.image ? 'border-neon-purple scale-105' : 'border-white/5 opacity-60'}`}>
                       <img src={img.image} className="w-full h-full object-cover" />
                    </button>
                 ))}
                 {projectImages.length === 0 && !isRefreshingHistory && <p className="text-gray-700 uppercase font-bold text-[10px] py-8">Empty History</p>}
              </div>
           </div>
        </main>
      </div>
    </div>
  );

  switch (currentView) {
    case 'AUTH': return renderAuth();
    case 'DASHBOARD': return renderDashboard();
    case 'CREATE_PROJECT': return renderCreateProjectModal();
    case 'STUDIO': return renderStudio();
    case 'LANDING':
    default: return renderLanding();
  }
};

export default App;
